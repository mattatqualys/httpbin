import logging

log_file_name = "execution.log"


def setup_logging():
    logging.basicConfig(filename=log_file_name,
                        filemode='a',
                        format='%(asctime)s [%(levelname)] %(message)s',
                        datefmt='%Y-%m-%d %H:%M:%S')


logger = logging.getLogger()
logger.setLevel(logging.INFO)  # set log level

line_format = '%(asctime)s (%(filename)s:%(lineno)d) [%(levelname)s] %(message)s'
# File handler
file_handler = logging.FileHandler(log_file_name, mode='a')
file_handler.setFormatter(logging.Formatter(line_format))

# Console handler
console_handler = logging.StreamHandler()
console_handler.setFormatter(logging.Formatter(line_format))

# Add handlers to logger
logger.addHandler(file_handler)
logger.addHandler(console_handler)
