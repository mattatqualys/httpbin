import sys
import requests
import logging
import json
import traceback


class ScanHarborRegistry:
    harbor_registry = None
    base_url = None
    headers_harbor = None
    auth = None
    proxies = None
    headers_qualys = None
    qualys_api_gateway_url = None
    qualys_access_token = None
    qualys_harbor_registry_uuid = None

    @classmethod
    def get_harbor_registry_details_and_create_ondemand_scan_jobs(cls):

        cls.validate_credentials()

        # iterate over /project/repo/tags and create jobs
        projects_list = cls.get_all_projects_in_the_registry(cls.harbor_registry)
        for project_name in projects_list:
            repository_list = cls.get_all_repository_in_the_project(project_name)
            for repo in repository_list:
                repository_name = repo.split(f"{project_name}/")[1]
                tag_list = cls.get_all_artifacts_with_tags_in_the_repository(project_name, repository_name)

                # create a repo_tag_list as a payload for the on demand scan job
                repo_tag_list = []
                try:
                    for tag in tag_list:
                        repo_tag_list.append({"repo": repo, "tag": tag})

                    # schedule on demand scan job for each repository - force scan false

                    if repo_tag_list:
                        logging.info(f"Creating on demand scan job for project/repository [{repo}]")
                        cls.schedule_on_demand_scan_job(cls.qualys_harbor_registry_uuid, repo_tag_list)
                    else:
                        logging.warning(f"No artifacts found in project/repository [{repo}] ")

                except Exception as e:
                    logging.error(f"Exception {type(e).__name__} occurred while parsing repo {repo}")
                    traceback.print_exc()
            #     break at repository level
            # break at project level

    @classmethod
    def validate_credentials(cls) -> None:
        url = f"{cls.base_url}/users/current"
        response = requests.get(url, auth=cls.auth)

        if response.status_code == 401:
            sys.exit(f"[ERROR] Unable to Login to Registry [401], please update config.json")

    @staticmethod
    def validate_response_status_code(response: requests.models.Response) -> None:
        msg_sys_exit = f"Expected [200], Received [{response.status_code}] for URL {response.url}"
        if response.status_code in [200, 404]:
            if response.status_code == 404:
                if "artifacts was not found" not in response.json()['errors'][0]['message']:
                    logging.error(msg_sys_exit)
                    sys.exit(msg_sys_exit)
        else:
            logging.error(msg_sys_exit)
            sys.exit(f"[sys.exit] {msg_sys_exit}")

    @classmethod
    def get_all_projects_in_the_registry(cls, registry_name: str) -> list:
        projects_list = []
        page_size = 10
        page = 1
        while True:
            params = {"page": page, "page_size": page_size}
            url = f"{cls.base_url}/projects?page={page}&page_size={page_size}&with_detail=false"
            response = requests.get(url, params=params, headers=cls.headers_harbor, auth=cls.auth)
            cls.validate_response_status_code(response)
            repositories = response.json()
            for repo in repositories:
                projects_list.append(repo['name'])
            page += 1

            if not response.json():
                break

        logging.info(f"Projects available in Registry {registry_name} >> {projects_list}")
        return projects_list

    @classmethod
    def get_all_repository_in_the_project(cls, project_name: str) -> list:
        repository_list = []
        page_size = 10
        page = 1
        while True:
            params = {"page": page, "page_size": page_size}
            url = f"{cls.base_url}/projects/{project_name}/repositories?page={page}&page_size={page_size}"
            response = requests.get(url, params=params, headers=cls.headers_harbor, auth=cls.auth)
            cls.validate_response_status_code(response)
            repositories = response.json()
            for repo in repositories:
                repository_list.append(repo['name'])
            page += 1

            if not response.json():
                break

        logging.info(f"Repositories available in project {project_name} >> {repository_list}")
        return repository_list

    @classmethod
    def get_all_artifacts_with_tags_in_the_repository(cls, project_name: str, repository_name) -> list:
        tag_list = []
        page_size = 1
        page = 1
        while True:
            params = {"page": page, "page_size": page_size}
            url = f"{cls.base_url}/projects/{project_name}/repositories/{repository_name}/artifacts?page={page}&page_size={page_size}&with_tag=true&with_label=false&with_scan_overview=false&with_signature=false&with_immutable_status=false"
            response = requests.get(url, params=params, headers=cls.headers_harbor, auth=cls.auth)
            cls.validate_response_status_code(response)
            repositories = response.json()
            artifact_found = True
            for repo in repositories:
                if repo == "errors":
                    logging.warning(f"No artifact found in {project_name}/{repository_name}")
                    artifact_found = False
                elif repo['tags'] is None:
                    logging.warning(f"Tag not found for image with digest: {repo['digest']}")
                else:
                    tag_list.append(repo['tags'][0].get('name'))
            page += 1

            if not response.json() or not artifact_found:  # if no more tags available or no artifact found
                break

        logging.info(f"Tags available in project/repository {project_name}/{repository_name} >> {tag_list}")
        return tag_list

    @classmethod
    def schedule_on_demand_scan_job(cls, registry_uuid: str, repo_tag_list: list):
        url = f"{cls.qualys_api_gateway_url}/csapi/v1.3/registry/{registry_uuid}/schedule"
        json_payload = {
            "filters": [
                {
                    "days": None,
                    "repoTags": repo_tag_list
                }
            ],
            "name": "OnDemand Scan Schedule",
            "onDemand": True,
            "schedule": "00:00",
            "pushedDateFilter": None,
            "forceScan": False,
            "registryType": "Harbor",
            "additionalFilters": None
        }
        try:
            if cls.proxies:
                response = requests.post(url, headers=cls.headers_qualys, proxies=cls.proxies, json=json_payload)
            else:
                response = requests.post(url, headers=cls.headers_qualys, json=json_payload)
            try:
                cls.validate_response_status_code(response)
                logging.info(f"Scan Job Created  - {response.json()}")
            except json.decoder.JSONDecodeError:
                logging.error(f"JSONDecodeError | url [{response.url}] | "
                              f"status_code {response.status_code} | response.text {response.text} ")
        except requests.exceptions.ProxyError:
            logging.info(f"ProxyError | Please update the config.json. Proxy can not be null if proxy_needed is true")
