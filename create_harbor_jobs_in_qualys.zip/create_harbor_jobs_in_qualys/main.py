import logging
import sys
import json
from requests.auth import HTTPBasicAuth
from logger import setup_logging

from methods import ScanHarborRegistry

if __name__ == "__main__":
    setup_logging()

    with open("config.json", "r") as f:
        config = json.load(f)

        # harbor
        harbor_registry = config['harbor_registry']
        harbor_username = config['harbor_username']
        harbor_password = config['harbor_password']

        # proxy
        proxy_needed = config['proxy_needed']
        proxy = config['proxy']

        # qualys
        qualys_api_gateway_url = config['qualys_api_gateway_url']
        qualys_access_token = config['qualys_access_token']
        qualys_harbor_registry_uuid = config['qualys_harbor_registry_uuid']

        if all(v is None for v in (harbor_registry, harbor_username, harbor_password,
                                   qualys_api_gateway_url, qualys_access_token, qualys_harbor_registry_uuid)):
            sys.exit(f"Exiting code, please update the config.json with correct values. Values can not be null.")

        if proxy_needed and proxy is None:
            sys.exit(f"Proxy can not be null if proxy_needed is true, please update the config.json.")

    # headers
    headers = {"Accept": "application/json",
               'Content-Type': 'application/json'}

    # class variables - Harbor
    ScanHarborRegistry.harbor_registry = harbor_registry
    ScanHarborRegistry.base_url = f"{harbor_registry}/api/v2.0"
    ScanHarborRegistry.headers_harbor = headers
    ScanHarborRegistry.auth = HTTPBasicAuth(harbor_username, harbor_password)
    ScanHarborRegistry.qualys_harbor_registry_uuid = qualys_harbor_registry_uuid

    # class variables - Qualys
    ScanHarborRegistry.qualys_api_gateway_url = qualys_api_gateway_url
    ScanHarborRegistry.qualys_access_token = qualys_access_token
    ScanHarborRegistry.headers_qualys = {**headers, 'Authorization': f'Bearer {qualys_access_token}'}

    if proxy_needed:
        ScanHarborRegistry.proxies = {
            "http": f"http://{proxy}",  # Example: "http://10.10.1.10:3128"
            "https": f"https://{proxy}"  # Example: "https://10.10.1.10:3128"
        }

    # main method
    ScanHarborRegistry.get_harbor_registry_details_and_create_ondemand_scan_jobs()

    logging.info("Execution Completed")
