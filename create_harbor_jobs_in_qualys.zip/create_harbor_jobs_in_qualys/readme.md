### Collect all tags in Harbor Registry and create ondemand scan jobs for each repo

    """
    # get all projects in the harbor registry
        # get all repos in each project
            # get all artifacts with tag on the repos >> Skipping the artifacts with no tags
    
    """

This is created with `pyhton 3.12`.Prerequisite please install the requirements

```
pip install -r requirements.txt

python3 main.py
```

#### Please check and update the config.json

```
{
  "harbor_registry": null,
  "harbor_username": null,
  "harbor_password": null,
  "proxy_needed": accepts true/false,
  "proxy": can not be null if proxy_needed is true, <ip:port> do not prefix with http or https 
  "qualys_api_gateway_url": null,
  "qualys_access_token": availale in configurations,
  "qualys_harbor_registry_uuid": open the registry on qulays platform, last part of registry url
}
```


